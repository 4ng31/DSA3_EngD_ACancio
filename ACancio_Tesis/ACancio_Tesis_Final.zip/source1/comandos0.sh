$ python datasim.py -q 16 -n 17694176 -o ${DIR}/fakeIFMS/fake16ifms1a.bin
$ python datasim.py -q 16 -n 17694176 -o ${DIR}/fakeIFMS/fake16ifms1a.bin
$ python datasim.py -q 16 -n 17694176 -o ${DIR}/fakeIFMS/fake16ifms1a.bin