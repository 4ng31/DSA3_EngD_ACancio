#include <iostream>
#include <fcntl.h>   // open
#include <unistd.h>  // read, write, close
#include <cstdio>    // BUFSIZ
#include <ctime>

extern "C"
{
    int CopyPrev(const char *inputname, const char *outputname, int offset)
    {
        size_t BUFFER_SIZE=1468; //1468*8
        
        char buf[BUFFER_SIZE];
        size_t size=0;
        
        int source = open(inputname, O_RDONLY, 0);
        int dest = open(outputname,  O_WRONLY | O_APPEND | O_CREAT , 0644);
        
        off_t fsize=0;
        
        lseek(dest, 0, SEEK_END);
        lseek(source, 0, SEEK_SET);    
        
        while ((size = read(source, buf, BUFFER_SIZE)) > 0) {
            fsize=lseek(source, 0, SEEK_CUR);
            if ( fsize > offset ){
                break;
            }
            write(dest, buf, size);
        }
        
        close(source);
        close(dest);
        return 0;
     }

    int CopyPost(const char *inputname, const char *outputname, int offset)
    {
        size_t BUFFER_SIZE=1468; //1468*8
        
        char buf[BUFFER_SIZE];
        size_t size=0;
        
        int source = open(inputname, O_RDONLY, 0);
        int dest = open(outputname, O_WRONLY | O_CREAT , 0644);
        
        lseek(source, 0, SEEK_SET);      
        lseek(source,offset,SEEK_SET);
        
        while ((size = read(source, buf, BUFFER_SIZE)) > 0) {
            write(dest, buf, size);
        }
        
        close(source);
        close(dest);
        return 0;
    }
}
