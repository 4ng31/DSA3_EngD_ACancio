def cudarms(data,qbits):
    import numpy as np
    import math
    import pycuda.autoinit
    import pycuda.driver as drv
    from pycuda.compiler import SourceModule

    dot_mod = SourceModule("""
    __global__ void full_dot( float* v1, float* v2, float* out, int N ) {
        __shared__ int cache[ 1024 ];
        int i = blockIdx.x * blockDim.x + threadIdx.x;
        //i += blockDim.x * gridDim.x;
        cache[ threadIdx.x ] = 0;
        while( i < N ) {
            cache[ threadIdx.x ] += v1[ i ] * v2[ i ] + v1[ i ];
            i += gridDim.x * blockDim.x;
        }
        __syncthreads(); // required because later on the current thread is accessing
                         // data written by another thread    
        i = 1024 / 2;
        while( i > 0 ) {
            if( threadIdx.x < i ) cache[ threadIdx.x ] += cache[ threadIdx.x + i ];
            __syncthreads();
            i /= 2; //not sure bitwise operations are actually faster
        }
    
    #ifndef NO_SYNC // serialized access to shared data; 
        if( threadIdx.x == 0 ) atomicAdd( out, cache[ 0 ] );
    #else // no sync, what most likely happens is:
          // 1) all threads read 0
          // 2) all threads write concurrently 16 (local block dot product)
        if( threadIdx.x == 0 ) *out += cache[ 0 ];
    #endif                
        
    }
    """)
    
    dot = dot_mod.get_function("full_dot")
    
    #Number of samples
    N=len(data)
    Ns=N/2 
    BLOCK_SIZE = 1024
    BLOCKS = int(math.ceil(N/BLOCK_SIZE))
    THREADS_PER_BLOCK = BLOCK_SIZE
    
    # Time use of pinned host memory:
    x = drv.aligned_empty((N), dtype=np.int32, order='C')
    x = drv.register_host_memory(x, flags=drv.mem_host_register_flags.DEVICEMAP)
    x_gpu_ptr = np.intp(x.base.get_device_pointer())
    
    # Time use of pinned host memory:
    y = drv.aligned_empty((N), dtype=np.int32, order='C')
    y = drv.register_host_memory(y, flags=drv.mem_host_register_flags.DEVICEMAP)
    y_gpu_ptr = np.intp(y.base.get_device_pointer())
    
    # Time use of pinned host memory:
    z = drv.aligned_empty((1), dtype=np.int32, order='C')
    z = drv.register_host_memory(z, flags=drv.mem_host_register_flags.DEVICEMAP)
    z_gpu_ptr = np.intp(z.base.get_device_pointer())
    
    z[:] = np.zeros(1)
    x[:] = np.zeros(N)
    y[:] = np.zeros(N)
    
    x[:] = data.astype(np.float32)
    y[:] = x[:] 
    
    dot(x_gpu_ptr, 
        y_gpu_ptr, 
        z_gpu_ptr, 
        np.uint32(N), 
        block=(THREADS_PER_BLOCK, 1, 1), grid=(BLOCKS,1))
    drv.Context.synchronize()
    
    #Mapping to signal value
    ydot=2**(16-qbits)*(float(z[0])+N*0.25)
        
    rms=np.sqrt(ydot/Ns)
    return rms