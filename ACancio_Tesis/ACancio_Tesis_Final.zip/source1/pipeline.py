import argparse
from libpipe import *
from filterdata import *
from libradsa import *
import proc
import gc
from contextlib import closing
from astropy.io import fits
from astropy.table import Table
import threading
import concurrent.futures
import glob

def copyandreduce(args):
    # Ejecutar solo si es la primera vez que se procesan los datos originales, 
    # y se desea reducir los datos a UDP validos.
    ## Schedule File
    if not (csvcheck(schd=args.schd)):
        csvbuild(schd=args.schd, qbits=args.qbits, fs=args.fs)
        if not (csvcheck(schd=args.schd)):
            raise ValueError("Please verify the format of your CSV Schedule File")
            
    ## Reduce Data, Valid UDP
    filterdata(schedulefile=args.schd,configfile=args.config,
               orkdir=args.workdir,surveypath=args.input,ifms=args.ifms)
    
def process(args):
    import glob   
    # Se recomienda el procesamiento de los datos reducidos.
    
    # Listado de archivos.
    files = glob.glob(args.workdir+'/*.bin')
    
    df=pd.DataFrame.from_dict({'Filename':[np.nan], 'Timestamp':[np.nan],
                               'Quantization':[np.nan], 
                               'SampleFrequency':[np.nan],
                               'IntegrationTime':[np.nan],
                               'rms_ch0':[np.nan], 'rms_ch1':[np.nan],
                               'rms_ch2':[np.nan], 'rms_ch3':[np.nan]}, 
                              orient='columns')
    maxw=4
    dictres=[]
    if args.cuda:
        print 'Processing over GPU...' 
        with concurrent.futures.ProcessPoolExecutor(max_workers=maxw) as pool:
            dictres = pool.map(proc.cudaproc, files)
    else:
        print 'Processing over CPU...' 
        with concurrent.futures.ProcessPoolExecutor(max_workers=maxw) as pool:
            dictres = pool.map(proc.cpuproc, files)
            
    for f in dictres:
        df=df.append(pd.DataFrame.from_dict(f,orient='columns'))
            
    ## Separate IFMS by groupby Filnames
    df.dropna(inplace=True)
    name=('%s/result.csv')%(args.workdir)
    df.to_csv(name)
    name=('%s/result.fits')%(args.workdir)
    t = Table.from_pandas(df)
    t.write(name,overwrite=True)
            
    print 'Done.'
    
def main(args):
    
    if args.feature == 'all':
        copyandreduce(args)
        process(args)
        
    if args.feature == 'reduce':
        copyandreduce(args)

    if args.feature == 'process':
        process(args)        
        
if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Pipeline for processing recorded data with DSA3 from ESA')    
    
    parser.add_argument('-r','--run', dest='feature', 
			help='ALL: Copy, reduce and process data.\n REDUCE: Copy and reduce data.\n PROCESS: Process reduced data.', 
			nargs='?', choices=('all', 'reduce', 'process'), required=True)
    parser.add_argument('-C','--cuda', dest='cuda', help='Enable GPU CUDA processing', required=False,action='store_true')

    parser.add_argument('-s', '--schedule', dest='schd',type=str, help='Schedule file.', required=True)
    
    parser.add_argument('-c', '--config', dest='config',type=argparse.FileType('r'), help='Config file.', required=False)
    parser.add_argument('-o', '--workdir', dest='workdir',type=str, help='Output directory PATH.', required=True)  
    parser.add_argument('-q', dest='qbits', type=int, choices=[2,4,8,16],help="Bits quantization", required=True)
    parser.add_argument('-f', '--frecquency', dest='fs',type=int, help='', required=True)
    parser.add_argument('-i', '--input', dest='input',type=str, help='Input directory PATH, Survey PATH.', required=True)
    parser.add_argument('-I', '--ifms', dest='ifms',type=str, help='1:Enable, 0:Disable, i.e 111 enables all IFMS 123 ', required=True)
        
    args = parser.parse_args()
    
    import time
    start_time = time.time()
    main(args)
    print("--- %s seconds ---" % (time.time() - start_time))