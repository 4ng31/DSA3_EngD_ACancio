
# Antena Data Processor 
import numpy as np
import sys,os
import argparse
from bitarray import bitarray
import math
import mmap
import pandas as pd
from libradsa import *
from readblock import *
import gc
from contextlib import closing
from concurrent import futures
import multiprocessing as mp
from functools import partial

import ctypes

def pool_init():  
    import gc
    gc.collect()

def remove(buff, idchunk):
    size = len(buff)
    bytes =1468
    skip=76
    subdata=bytearray()
    for i in range(0, size, bytes):
        subdata += buff[i+skip:i+bytes]
        
    return subdata

    
def removeheader(INFILE):
    SIZE = os.stat(INFILE).st_size
    ncpus = mp.cpu_count()    
    output = bytearray(b'\x00')*SIZE
    with open(INFILE, 'rb') as f:
        f.readinto(output)
    
    nblocks=len(output)/1468
    nchunks=nblocks//ncpus
    chunksize=nchunks*1468
    
    tasks = []
    for i in range(ncpus-1):
        start=i*chunksize
        end=(i+1)*chunksize
        tasks.append( (output[start:end],i) )
    tasks.append( (output[end:len(output)],i) )

    data=bytearray()
    
    with closing( mp.Pool(processes=ncpus,initializer=pool_init, maxtasksperchild=1) ) as pool:
        results = [pool.apply( remove, t ) for t in tasks]
    
    
    for i in results:
        data+=i
        
    del output        
    return data

def removeheader1(INFILE):
    SIZE = os.stat(INFILE).st_size
    BYTES=1468
    SKIP=76
    NEWBYTES=1392
    NEWSIZE=SIZE/BYTES*NEWBYTES
    
    with open(INFILE, 'rb') as fd:
        mm = mmap.mmap(fd.fileno(), 0, prot=mmap.PROT_READ)
        newoffset=0
        data = bytearray(NEWSIZE)
        for offset in range(0, SIZE, BYTES):
            data[newoffset:newoffset+NEWBYTES] = mm[offset+SKIP:offset+BYTES]
            newoffset += NEWBYTES
    del mm
    gc.collect()
    return data

def readdeco(buff,qbits):
    datastream = bitarray()
    datastream.frombytes(buff)

    ## Read data
    chl0,chl1,chl2,chl3=demux(datastream)
    del buff
    del datastream
    gc.collect()
    
    if qbits == 2:
        CH0,CH1,CH2,CH3=decode2bit(chl0,chl1,chl2,chl3)
    elif qbits == 4:
        CH0,CH1,CH2,CH3=decode4bit(chl0,chl1,chl2,chl3)
    elif qbits == 8:
        CH0,CH1,CH2,CH3=decode8bit(chl0,chl1,chl2,chl3)
    elif qbits == 16:
        CH0,CH1,CH2,CH3=decode16bit(chl0,chl1,chl2,chl3)    
    
    return (CH0,CH1,CH2,CH3)

def multireaddeco(buff,qbits):
    
    ncpus = mp.cpu_count()

        
    nblocks=len(buff)/1392
    nchunks=nblocks//ncpus
    chunksize=nchunks*1392

    tasks = []
    for i in range(ncpus-1):
        start=i*chunksize
        end=(i+1)*chunksize
        tasks.append( (buff[start:end],qbits) )
    tasks.append( (buff[end:len(buff)],qbits) )
    del buff
    
    if (ncpus >= 4):
        with closing( mp.Pool(processes=4,initializer=pool_init,maxtasksperchild=1) ) as pool:
            results = [pool.apply( readdeco, t ) for t in tasks]  
    else:
        with closing( mp.Pool(processes=ncpus,initializer=pool_init,maxtasksperchild=1) ) as pool:
            results = [pool.apply( readdeco, t ) for t in tasks]  
           
    CH0=np.array([])
    CH1=np.array([])
    CH2=np.array([])
    CH3=np.array([])
    for i in results:
        CH0=np.append(CH0, i[0])
        CH1=np.append(CH1, i[1])
        CH2=np.append(CH2, i[2])
        CH3=np.append(CH3, i[3])
        
    del results
    gc.collect()
        
    return [CH0,CH1,CH2,CH3]
        
def cpurms(x,qbits):
    #Mapping to signal value
    val=2**(16-qbits)  
    x=(x+0.5)*val
    #Number of samples, divided by 2 (one sample per IQ pair)
    Ns=len(x)/2       
    y = x.copy()
    ydot=np.dot(x,y)
    
    rms=np.sqrt(ydot/Ns)
    
    return rms

def cudarms_aux(data, qbits):
    r=cudarms(data, qbits)
    return r
    
def cudarms(data, qbits):
    import pycuda.autoinit
    import pycuda.gpuarray as gpuarray
    #Number of samples
    N=len(data)
    Ns=N/2 
    
    data=2**(16-qbits)*(data+0.5)
    a_gpu = gpuarray.to_gpu(data)
    b_gpu = gpuarray.to_gpu(data)
    c_gpu = gpuarray.dot(a_gpu, b_gpu)
    
    rms=np.sqrt(c_gpu.get()/Ns)
    return rms

def cudaproc(filename):

    res=[]
    #Read Firs block to get Timestamp, Quantization, SampleFrequency, IntegrationTime, 4*FrequencyChannels, 4*RMS
    res=readfirstblock(filename)
    qbits=res['Quantization']
    
    # Process al UDP packets by Removing Headers, Demux bitarray, Decode array, Mapping, RMS Calc
    auxbuf=removeheader(filename)    
    lch=[]
    lch = multireaddeco(bytes(auxbuf),qbits)
    del auxbuf
    
    rms=[]
    qb=np.ones(4,dtype=np.int)*qbits
    with futures.ProcessPoolExecutor(max_workers=4) as pool:
        rms = pool.map(cudarms_aux, lch, qb)
    rms=[f for f in rms]        
    # Return: [Timestamp, Filename, IFMStag, Quantization, SampleFrequency, 
    #          IntegrationTime, 4*FrequencyChannels, 4*RMS]
    res.update({'rms_ch0':[rms[0]],'rms_ch1':[rms[1]],
                'rms_ch2':[rms[2]],'rms_ch3':[rms[3]]})
    
    return res

def cpuproc_aux(filename):
    res=[]
    #Read Firs block to get Timestamp, Quantization, SampleFrequency, IntegrationTime, 4*FrequencyChannels, 4*RMS
    res=readfirstblock(filename)
    qbits=res['Quantization']
    # Process al UDP packets by Removing Headers, Demux bitarray, Decode array, Mapping, RMS Calc
    auxbuf=removeheader(filename)    
    lch=[]
    lch = multireaddeco(bytes(auxbuf),qbits)
    del auxbuf
    
    ncpus = mp.cpu_count()
    if (ncpus >= 4):
        with closing( mp.Pool(processes=4,initializer=pool_init,maxtasksperchild=1) ) as pool:
            rms = [pool.apply( cpurms, args=(channel, qbits) ) for channel in lch]   
    else:
        with closing( mp.Pool(processes=ncpus, initializer=pool_init,maxtasksperchild=1) ) as pool:
            rms = [pool.apply( cpurms, args=(channel, qbits) ) for channel in lch]   

    # Return: [Timestamp, Filename, IFMStag, Quantization, SampleFrequency, IntegrationTime, 4*FrequencyChannels, 4*RMS]
    res.update({'rms_ch0':[rms[0]],'rms_ch1':[rms[1]],'rms_ch2':[rms[2]],'rms_ch3':[rms[3]]})
    return res

def cpuproc(filename):
    resul=cpuproc_aux(filename)
    gc.collect()
    return resul