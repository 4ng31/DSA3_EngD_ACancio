
import datetime
import numpy as np
import os
import mmap
import struct
import ctypes
from bitstring import BitStream, ConstBitStream,Bits
from bitstring import BitArray as bt
from bitarray import bitarray as BitArray

def readheader(BS,hprint=None):
    """Reads the header of a UNIX format raw data file.
    Notes
    =====
    @param BS : byte stream
    """
    
    from bitstruct import unpack
    
    header={}
    header["magic"],header["recordlength"],header["hdrlen"],header["blocksize"],\
    header["samplerate"],header["cfegain"],header["qu"],header["msg"],\
    header["frameid"],header["version"],header["timetag_samps"],header["offsetfreq"],\
    header["timetag_secs"],header["subc"],header["digitalgain"],header["subchan0_offset"],\
    header["subchan1_offset"],header["subchan2_offset"],header["subchan3_offset"],\
    header["sweeprate"],header["path_delay"],header["gdspid"],header["hs"],\
    header["semr"],header["sweepchange"],header["ncov"],header["ncoreset_c"],\
    header["ncoreset_t"],empty = unpack('>r32u16u8u8u16u10u3u3u32u7u25s32u17u4u11s32s32s32s32s32s32u8u1s12u11u1s11u20r128', BS)
                  
    if hprint:
        import yaml
        print(yaml.dump(header, default_flow_style=False))
        
    return header

def copypost(src, dst, offset):
    with open(src, 'rb') as f1:
        f1.seek(offset,0)
        with open(dst, 'ab') as f2:
            f2.write(f1.read())

def copyprev(src,dst, offset):
    with open(src, 'rb') as f1:
        with open(dst, 'ab') as f2:
            f2.write(f1.read(offset))

    
def sec2time(sec, n_msec=3):
    ''' Convert seconds to 'D days, HH:MM:SS.FFF' '''
    if hasattr(sec,'__len__'):
        return [sec2time(s) for s in sec]
    m, s = divmod(sec, 60)
    h, m = divmod(m, 60)
    d, h = divmod(h, 24)
    if n_msec > 0:
        pattern = '%%02d:%%02d:%%0%d.%df' % (n_msec+3, n_msec)
    else:
        pattern = r'%02d:%02d:%02d'
    if d == 0:
        return pattern % (h, m, s)
    return ('%d days, ' + pattern) % (d, h, m, s)

def readblock(filepointer, startbyte,endbyte):
    a = bt(filepointer)
    H=76*8
    R=1392*8
    pkg=H+R
    print a.len
    for i in range(0,a.len/pkg):
        del a[i*(R):i*(R)+H]
    print a.len
    
def readfirstblock(INFILE):
    SIZE = os.stat(INFILE).st_size
    BYTES=1468
    HEADER=76
    
    with open(INFILE, 'rb') as fd:
        mm = mmap.mmap(fd.fileno(), 0, prot=mmap.PROT_READ)
        BS= mm[0:HEADER]
        header1 = readheader(BS,hprint=None)
        X=np.float64(header1["timetag_samps"])*np.float64(1./17500000)
        Y=np.float64(header1["path_delay"])*np.float64(1./35000000)
        utctime1=np.float64(header1["timetag_secs"])+X-Y
        ttime1=sec2time(utctime1,6)
        BS = mm[SIZE-BYTES:SIZE-BYTES+HEADER]
        header2 = readheader(BS,hprint=None)
        X=np.float64(header2["timetag_samps"])*np.float64(1./17500000)
        Y=np.float64(header2["path_delay"])*np.float64(1./35000000)
        utctime2=np.float64(header2["timetag_secs"])+X-Y
        ttime2=sec2time(utctime2,6)
    
    recordlength=utctime2-utctime1
    fs=17500000./header1["samplerate"]
    qu=header1["qu"]
    if qu == 0: 
        qu=1
    if qu ==1:
        qu=2
    if qu == 2:
        qu=4
    if qu == 4:
        qu=8
    if qu == 5:
        qu=16
    
    #[Filename, Timestamp, Quantization, SampleFrequency, IntegrationTime,
    info={'Filename':INFILE.split("/")[-1],'Timestamp':ttime1, 'Quantization':qu, 'SampleFrequency':fs, 'IntegrationTime':recordlength}
    return info

def checkfile(INFILE,itime):
    SIZE = os.stat(INFILE).st_size
    print SIZE
    if SIZE == 0:
        return False
    
    BYTES=1468
    HEADER=76
    
    with open(INFILE, 'rb') as fd:
        mm = mmap.mmap(fd.fileno(), 0, prot=mmap.PROT_READ)
        BS= mm[0:HEADER]
        header1 = readheader(BS,hprint=None)
        X=np.float64(header1["timetag_samps"])*np.float64(1./17500000)
        Y=np.float64(header1["path_delay"])*np.float64(1./35000000)
        utctime1=np.float64(header1["timetag_secs"])+X-Y
        ttime1=sec2time(utctime1,6)
        BS = mm[SIZE-BYTES:SIZE-BYTES+HEADER]
        header2 = readheader(BS,hprint=None)
        X=np.float64(header2["timetag_samps"])*np.float64(1./17500000)
        Y=np.float64(header2["path_delay"])*np.float64(1./35000000)
        utctime=np.float64(header2["timetag_secs"])+X-Y
        ttime2=sec2time(utctime2,6)
    
    diff=utctime2-utctime1
    return np.isclose(itime,diff,rtol=1e-4)

def datareduce(schdtimes,filelist,filetimes,scannumber,output,integrationtime):
    TestLib = ctypes.cdll.LoadLibrary('./TestLib.so')

    
    output="%s%s_scan_%04d.bin" % (output, '_'.join((filelist[0].split('/')[-1]).split('_')[:-1]),scannumber)
    ## Check if file exist and is correct
    if os.path.isfile(output):
        ## Check if file has the correct length
        if checkfile(output,integrationtime):
            print 'File exist and is correct'
            return 0
        else:
            print 'File exist, but is not correct, deleting...'
            os.remove(output)
    
    for i in np.arange(2):
        with open(filelist[i]) as fd:
            mm = mmap.mmap(fd.fileno(), 0, prot=mmap.PROT_READ)
            header = readheader(mm[0:76],hprint=None)

        fs=header["samplerate"]
        qu=header["qu"]
        
        if qu == 5: #16-bits
            nsamples=87
        
        freq=17500000./(fs)
        timefilestart=filetimes[i]
        filename=filelist[i]
        
        filesize=os.path.getsize(filename)
        
        blocksize=1468
        N=float(filesize)/blocksize
        T=1./freq
        sec=T*nsamples*N
        
        ## Calculate end time file (next startimefie)
        delta=datetime.timedelta(seconds=sec)
        
        tschdstart=schdtimes[0]
        tschdend=schdtimes[1]
        
        tfilestart=timefilestart
        tfileend=tfilestart+delta
        
        ## Lower bound
        if  tfilestart < tschdstart < tfileend:
            tdiff = tschdstart-tfilestart
            tdiff = tdiff.seconds+1e-6*tdiff.microseconds
            N1 = int(tdiff/(T*87))
            offset=blocksize*N1
            #### Bytes Offset file
            res=TestLib.CopyPost( ctypes.c_char_p(filename), ctypes.c_char_p(output), offset)
        
        ## Upper bound        
        if  tfilestart < tschdend < tfileend:
            tdiff = tschdend-tfilestart
            tdiff = tdiff.seconds+1e-6*tdiff.microseconds
            N1 = int(tdiff/(T*87))
            offset=blocksize*N1
            #### Bytes Offset file
            res=TestLib.CopyPrev( ctypes.c_char_p(filename), ctypes.c_char_p(output), offset)

    return output