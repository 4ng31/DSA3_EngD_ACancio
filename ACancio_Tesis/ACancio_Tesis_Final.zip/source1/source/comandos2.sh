$ python cudadataproc.py -q 16 -i1 ${DIR}/fakeIFMS/fake16ifms1a.bin \ 
                               -i2 ${DIR}/fakeIFMS/fake16ifms2a.bin \ 
                               -i3 ${DIR}/fakeIFMS/fake16ifms3a.bin