# Antena Data Processor 
import sys,os
import argparse

import gc

from libradsa import *

from pycuda import reduction
import pycuda.gpuarray as gpuarray
import pycuda.driver as cuda
import pycuda.autoinit
import numpy as np
from bitarray import bitarray

def gpureaddeco(filename,qbits):

    print "Read file"

    datastream = bitarray()
    if filename:
        with open(filename) as f:
            datastream.fromfile(f)
        
    ## Read data
    chl0,chl1,chl2,chl3=demux(datastream)
    
    del datastream        
    gc.collect()
    
    print "Demultiplexed array"
    
    if qbits == 2:
        CH0,CH1,CH2,CH3=decode2bit(chl0,chl1,chl2,chl3)
    elif qbits == 4:
        CH0,CH1,CH2,CH3=decode4bit(chl0,chl1,chl2,chl3)
    elif qbits == 8:
        CH0,CH1,CH2,CH3=decode8bit(chl0,chl1,chl2,chl3)
    elif qbits == 16:
        CH0,CH1,CH2,CH3=gpudecode16bit(chl0,chl1,chl2,chl3)    
    
    del chl0
    del chl1
    del chl2
    del chl3
    gc.collect()
    
    print "Decoded array"
    
    return [CH0,CH1,CH2,CH3]


def main(args):
    
    lfile=[args.infileifms1, args.infileifms2, args.infileifms3]
    
    dt1=np.dtype(np.float64)
    krnl = reduction.ReductionKernel(dt1, neutral="0",
                                     reduce_expr="a+b", map_expr="x[i]*y[i]",
                                     arguments="double *x, double *y")

    for name in lfile:
        
        start_t=time.time()
        a=gpureaddeco(name,args.qbits)
        print("--- Decode: %s seconds ---" % (time.time() - start_t))
        
        start_t=time.time()
        
        N=(a[0].shape)[0]/2
        
        print "Calculate RMS"
        x0_dot_prod = krnl(a[0], a[0])
        x1_dot_prod = krnl(a[1], a[1])
        x2_dot_prod = krnl(a[2], a[2])
        x3_dot_prod = krnl(a[3], a[3])
        
        RMS0=np.sqrt(x0_dot_prod.get()/N)
        RMS1=np.sqrt(x1_dot_prod.get()/N)
        RMS2=np.sqrt(x2_dot_prod.get()/N)
        RMS3=np.sqrt(x3_dot_prod.get()/N)

        IFMS=(",%f"*4)[1:] % (RMS0,RMS1,RMS2,RMS3)
        print("---RMS calc: %s seconds ---" % (time.time() - start_t))

        string = "%s, %s" % (os.path.basename(name), IFMS)
    
        with open(args.out, 'aw') as file:
            file.write(string)
            file.write("\n")

if __name__ == "__main__":
    
    import time
    start_time = time.time()
    
    parser = argparse.ArgumentParser(description='Simulate antena data format.')
    parser.add_argument('-q', dest='qbits', type=int, choices=[2,4,8,16],
                        help="Bits quantization", required=True)
    parser.add_argument('-i1', '--infileifms1', dest='infileifms1',
                        help='Read from IN_FILE the simulated data.', required=True)
    parser.add_argument('-i2', '--infileifms2', dest='infileifms2',
                        help='Read from IN_FILE the simulated data.', required=True)
    parser.add_argument('-i3', '--infileifms3', dest='infileifms3',
                        help='Read from IN_FILE the simulated data.', required=True)
    parser.add_argument('-o', '--out', dest='out',
                        help='Output file where store the result.', required=True)
    
    args = parser.parse_args()
    
    main(args)
    print("--- %s seconds ---" % (time.time() - start_time))