# Antena Data Processor 
import numpy as np
import sys,os
import argparse
from bitarray import bitarray
import math
import gc
from libradsa import *

import multiprocessing
from multiprocessing.dummy import Pool as ThreadPool
from functools import partial

import ctypes
# ctypes.CDLL('libgomp.so.1', mode=ctypes.RTLD_GLOBAL)
# ctypes.cdll.LoadLibrary('libcusolver.so')

def readdeco(filename,qbits):

    print "Read file"

    datastream = bitarray()
    if filename:
        with open(filename) as f:
            datastream.fromfile(f)
        
    ## Read data
    chl0,chl1,chl2,chl3=demux(datastream)
    
    del datastream        
    gc.collect()
    
    print "Demultiplexed array"
    
    if qbits == 2:
        CH0,CH1,CH2,CH3=decode2bit(chl0,chl1,chl2,chl3)
    elif qbits == 4:
        CH0,CH1,CH2,CH3=decode4bit(chl0,chl1,chl2,chl3)
    elif qbits == 8:
        CH0,CH1,CH2,CH3=decode8bit(chl0,chl1,chl2,chl3)
    elif qbits == 16:
        CH0,CH1,CH2,CH3=decode16bit(chl0,chl1,chl2,chl3)    
    
    del chl0
    del chl1
    del chl2
    del chl3
    gc.collect()
    
    print "Decoded array"
    
    return CH0,CH1,CH2,CH3

def main(args):
    
    lfile=[args.infileifms1, args.infileifms2, args.infileifms3]
    
    dt1=np.dtype(np.float64)
 
    for name in lfile:
        
        start_t=time.time()
        a=np.array(readdeco(name,args.qbits))
        print("--- Decode: %s seconds ---" % (time.time() - start_t))
        
        start_t = time.time()
      
        a=a.astype(dt1)
        N=(a.shape)[1]/2

        print "Calculate RMS"
        y0=np.dot(a[0],a[0])
        y1=np.dot(a[1],a[1])
        y2=np.dot(a[2],a[2])
        y3=np.dot(a[3],a[3])
        
        RMS=(np.sqrt(y0/N),np.sqrt(y1/N),np.sqrt(y2/N),np.sqrt(y3/N))
        IFMS=(",%f"*4)[1:] % RMS
        del RMS
        del a

        print("---RMS calc: %s seconds ---" % (time.time() - start_t))
    
        string = "%s, %s" % (os.path.basename(name), IFMS)
    
        with open(args.out, 'aw') as file:
            file.write(string)
            file.write("\n")

if __name__ == "__main__":
    
    import time
    start_time = time.time()
    
    parser = argparse.ArgumentParser(description='Simulate antena data format.')
    parser.add_argument('-q', dest='qbits', type=int, choices=[2,4,8,16],
                        help="Bits quantization", required=True)
    parser.add_argument('-i1', '--infileifms1', dest='infileifms1',
                        help='Read from IN_FILE the simulated data.', required=True)
    parser.add_argument('-i2', '--infileifms2', dest='infileifms2',
                        help='Read from IN_FILE the simulated data.', required=True)
    parser.add_argument('-i3', '--infileifms3', dest='infileifms3',
                        help='Read from IN_FILE the simulated data.', required=True)
    parser.add_argument('-o', '--out', dest='out',
                        help='Output file where store the result.', required=True)
    
    args = parser.parse_args()
    
    main(args)
    print("--- %s seconds ---" % (time.time() - start_time))